function Show-Version {
@"
Rex
Created By Emanuelle Garduno emanuelle.garduno@gmail.com
Version 0.10-Beta
"@ | Write-Host
}
